# 使用PicGo+GitHub打造最稳定可靠的免费图床

## 创建自己的GitHub图床

### 1.创建GitHub图床之前，需要注册/登陆GitHub账号

申请`GitHub`账号并登陆到`GitHub`官网。

### 2.创建Repository

在个人选项栏中点击`New repository`

![](D:\个人学习笔记\技术\GitHub构建图床\1.jpg)



添加`Repository`相关的一些设置
![](D:\个人学习笔记\技术\GitHub构建图床\2.jpg)

### 3.生成一个Token用于操作GitHub Repository

在个人栏中选择`Settings`
![](D:\个人学习笔记\技术\GitHub构建图床\3.jpg)

点击左侧的`Developer settings`

![](D:\个人学习笔记\技术\GitHub构建图床\4.jpg)

点击`Personal access tokens`为上面创建的`Repository`创建一个Token

![](D:\个人学习笔记\技术\GitHub构建图床\5.jpg)

创建一个新的`Token`，并配置信息。

![](D:\个人学习笔记\技术\GitHub构建图床\6.jpg)

创建成功复制生成的`Token`，**这里注意**：生成要提前复制保存，关闭了就看不到了，只能再次生成一次Token。

## 配置PicGo

### 1.下载运行PicGo

在官网下载[PicGo](https://molunerfinn.com/PicGo/)，根据自己的操作系统进行下载。

### 2.配置图床

按照下图进行`GitHub`图床配置

![](D:\个人学习笔记\技术\GitHub构建图床\7.jpg)

### 3.快捷键及相关配置

### 4.其他相关

